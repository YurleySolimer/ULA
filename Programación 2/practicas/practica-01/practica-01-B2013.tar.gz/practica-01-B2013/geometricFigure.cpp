#include "geometricFigure.h"

GeometricFigure::GeometricFigure() {
	/* empty */
}
