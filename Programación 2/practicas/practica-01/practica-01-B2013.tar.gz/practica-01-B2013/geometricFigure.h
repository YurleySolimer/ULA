#ifndef GEOMETRICFIGURE_H
#define GEOMETRICFIGURE_H

#include "point.h"

class GeometricFigure {

public:
	GeometricFigure();

};

#endif // GEOMETRICFIGURE_H
