#include "vehiculo.h"

Vehiculo::Vehiculo() {
	leerDatos();
}

Vehiculo::Vehiculo(const int &_id, const string &_marca, //
				   const string &_modelo, const int &_anyo) //
	: id(_id), marca(_marca), modelo(_modelo), anyo(_anyo) {
	// empty
}

Vehiculo::Vehiculo(const Vehiculo &vehiculo) //
	: id(vehiculo.id), marca(vehiculo.marca), //
	  modelo(vehiculo.modelo), anyo(vehiculo.anyo) {
	// empty
}

Vehiculo::~Vehiculo() {
	// empty
}

int Vehiculo::getId() {
	return this->id;
}

void Vehiculo::setId(const int &id) {
	this->id = id;
}

string Vehiculo::getMarca() {
	return this->marca;
}

void Vehiculo::setMarca(const string &marca) {
	this->marca = marca;
}

string Vehiculo::getModelo() {
	return this->modelo;
}

void Vehiculo::setModelo(const string &modelo) {
	this->modelo = modelo;
}

int Vehiculo::getAnyo() {
	return this->anyo;
}

void Vehiculo::setAnyo(const int &anyo) {
	this->anyo = anyo;
}

double Vehiculo::getPesoCosto() {
	return this->pesoCosto;
}

void Vehiculo::setPesoCosto(const double &pesoCosto) {
	this->pesoCosto = pesoCosto;
}

void Vehiculo::leerDatos() {

	cout << endl << "Ingrese los datos del vehículo:" << endl
		 << endl << "Id: ";
	cin >> id;

	cout << "Marca: ";
	cin >> marca;

	cout << "Modelo: ";
	cin >> modelo;

	cout << "Año: ";
	cin >> anyo;

}

void Vehiculo::mostrarDatos() {

	cout << endl << "Datos del vehículo:"
		 << endl << "Id: " << id
		 << endl << "Marca: " << marca
		 << endl << "Modelo: " << modelo
		 << endl << "Año: " << anyo;

}
