#ifndef CLIENTE_PREFERENCIAL_H
#define CLIENTE_PREFERENCIAL_H

#include "empleado.h"
#include "cliente.h"

class ClientePreferencial : public Empleado, public Cliente {

public:
	ClientePreferencial();

	ClientePreferencial(const int &ced, const string &nom, //
						const string &dir, TipoEmpleado tipo);

	ClientePreferencial(const int &ced, const string &nom, //
						const string &dir, TipoEmpleado tipo, //
						Vehiculo *_vehiculo);

	ClientePreferencial(ClientePreferencial *clientePreferencial);

	~ClientePreferencial();

	void setDescuentoPreferencial();

	void mostrarClientePreferencial();

};

#endif // CLIENTE_PREFERENCIAL_H
