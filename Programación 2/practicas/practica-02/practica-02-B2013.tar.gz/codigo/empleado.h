#ifndef EMPLEADO_H
#define EMPLEADO_H

#include "persona.h"

enum TipoEmpleado {
	Contratado,
	Fijo,
	Administrativo,
	ManoDeObra,
	Antiguo
};

class Empleado : virtual public Persona {

	TipoEmpleado tipoEmpleado;

public:
	Empleado();

	Empleado(const int &ced, const string &nom, const string &dir, TipoEmpleado tipo);

	Empleado(Empleado *empleado);

	~Empleado();

	TipoEmpleado getTipoEmpleado();

	void setTipoEmpleado(TipoEmpleado tipoEmpleado);

	void mostrarEmpleado();

	string tipoEmpleadoToString();

protected:
	void leerDatos();
	void leerTipoEmpleado();

};

#endif // EMPLEADO_H
