#ifndef LAVADO_H
#define LAVADO_H

#include "cliente.h"

enum TipoLavado {
	Normal,
	Gamuzado,
	Motor,
	NormalGamuzado,
	NormalMotor,
	Full
};

class Lavado {

	TipoLavado tipoLavado;
	double costo;

	Cliente *cliente;

public:
	Lavado();

	Lavado(TipoLavado _tipoLavado);

	Lavado(Cliente *_cliente);

	Lavado(TipoLavado _tipoLavado, Cliente *_cliente);

	Lavado(const Lavado &lavado);

	~Lavado();

	TipoLavado getTipoLavado();

	void setTipoLavado(TipoLavado tipoLavado);

	double getCosto();

	void setCosto();

	void setCosto(const double &costo);

	Cliente *getCliente();

	void setCliente(Cliente *_cliente);

	void mostrarLavado();

private:
	double getCostoTipoLavado();
	string tipoLavadoToString();

};

#endif // LAVADO_H
