#include "clientePreferencial.h"
#include "moto.h"
#include "carro.h"
#include "camion.h"
#include "lavado.h"

int main() {

	Persona persona(1, "Jose", "Merida");
	persona.mostrarPersona();

	cout << endl;

	Cliente cliente(2, "Cliente", "Dir Cliente");
	cliente.mostrarCliente();

	cout << endl;

	Empleado empleado(3, "Empleado", "Dir Empleado", Administrativo);
	empleado.mostrarEmpleado();

	cout << endl;

	ClientePreferencial clientePreferencial(
				4, "Preferencial", "El Vigia", ManoDeObra);
	clientePreferencial.mostrarClientePreferencial();

	cout << endl;

	Vehiculo vehiculo(5, "Ford", "Fiesta", 2005);
	vehiculo.mostrarDatos();

	cout << endl;

	Moto moto(6, "Bera", "Socialista", 2013);
	moto.mostrarDatos();

	cout << endl;

	Carro carro(7, "Toyota", "Corolla", 2010);
	carro.mostrarDatos();

	cout << endl;

	Camion camion(8, "Ford", "350", 2014);
	camion.mostrarDatos();

	cout << endl << endl << "* Lavados Sin Descuento *" << endl;

	cliente.setVehiculo(&moto);
	Lavado lavadoMoto(Normal, &cliente);
	lavadoMoto.mostrarLavado();

	cout << endl;

	cliente.setVehiculo(&carro);
	Lavado lavadoCarro(Normal, &cliente);
	lavadoCarro.mostrarLavado();

	cout << endl;

	cliente.setVehiculo(&camion);
	Lavado lavadoCamion(Normal, &cliente);
	lavadoCamion.mostrarLavado();

	cout << endl << endl << "* Lavados Con Descuento *" << endl;

	clientePreferencial.setVehiculo(&moto);
	Lavado lavadoMotoPref(Gamuzado, &clientePreferencial);
	lavadoMotoPref.mostrarLavado();

	cout << endl;

	clientePreferencial.setVehiculo(&carro);
	Lavado lavadoCarroPref(NormalGamuzado, &clientePreferencial);
	lavadoCarroPref.mostrarLavado();

	cout << endl;

	clientePreferencial.setVehiculo(&camion);
	Lavado lavadoCamionPref(Full, &clientePreferencial);
	lavadoCamionPref.mostrarLavado();

	cout << endl;
	return 0;

}
