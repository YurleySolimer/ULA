#ifndef PERSONA_H
#define PERSONA_H

#include <iostream>
#include <string>

using namespace std;

class Persona {

	int cedula;
	string nombre;
	string direccion;

public:
	Persona();

	Persona(const int &ced, const string &nom, const string &dir);

	Persona(const Persona &persona);

	~Persona();

	int getCedula();

	void setCedula(const int &cedula);

	string getNombre();

	void setNombre(const string &nombre);

	string getDireccion();

	void setDireccion(const string &direccion);

	void mostrarPersona();

protected:
	virtual void leerDatos();

};

#endif // PERSONA_H
