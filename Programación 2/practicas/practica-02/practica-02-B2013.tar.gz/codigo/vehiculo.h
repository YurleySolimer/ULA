#ifndef VEHICULO_H
#define VEHICULO_H

#include <iostream>
#include <string>

using namespace std;

class Vehiculo {

	int id;
	string marca;
	string modelo;
	int anyo;
	double pesoCosto;

public:
	Vehiculo();

	Vehiculo(const int &_id, const string &_marca, //
			 const string &_mod, const int &_anyo);

	Vehiculo(const Vehiculo &vehiculo);

	~Vehiculo();

	int getId();

	void setId(const int &id);

	string getMarca();

	void setMarca(const string &marca);

	string getModelo();

	void setModelo(const string &modelo);

	int getAnyo();

	void setAnyo(const int &anyo);

	double getPesoCosto();

	void setPesoCosto(const double &pesoCosto);

	void leerDatos();

	void mostrarDatos();

};

#endif // VEHICULO_H
