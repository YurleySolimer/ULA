#ifndef CARRO_H
#define CARRO_H

#include "vehiculo.h"

#define PESO_COSTO_CARRO 1

class Carro : public Vehiculo {

public:
	Carro();

	Carro(const int &_id, const string &_marca, //
		  const string &_modelo, const int &_anyo);

	Carro(Carro *carro);

	~Carro();

};

#endif // CARRO_H
