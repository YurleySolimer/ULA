#include "persona.h"

Persona::Persona() {
	leerDatos();
}

Persona::Persona(const int &ced, const string &nom, const string &dir) //
	: cedula(ced), nombre(nom), direccion(dir) {
	// empty
}

Persona::Persona(const Persona &persona) //
	: cedula(persona.cedula), //
	  nombre(persona.nombre), //
	  direccion(persona.direccion) {
	// empty
}

Persona::~Persona() {
	// empty
}

int Persona::getCedula() {
	return this->cedula;
}

void Persona::setCedula(const int &cedula) {
	this->cedula = cedula;
}

string Persona::getNombre() {
	return this->nombre;
}

void Persona::setNombre(const string &nombre) {
	this->nombre = nombre;
}

string Persona::getDireccion() {
	return this->direccion;
}

void Persona::setDireccion(const string &direccion) {
	this->direccion = direccion;
}

void Persona::leerDatos() {

	cout << endl << "Ingrese los datos de la persona:" << endl
		 << endl << "Cédula: ";
	cin >> cedula;

	cout << "Nombre: ";
	cin >> nombre;

	cout << "Dirección: ";
	cin >> direccion;

}

void Persona::mostrarPersona() {

	cout << "Datos de la persona: "
		 << "\nCédula: " << cedula
		 << "\nNombre: " << nombre
		 << "\nDirección: " << direccion;

}
