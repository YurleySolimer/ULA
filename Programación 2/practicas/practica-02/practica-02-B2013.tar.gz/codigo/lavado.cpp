#include "lavado.h"

Lavado::Lavado() : tipoLavado(Normal), costo(0.0), //
	cliente(NULL) {
	// empty
}

Lavado::Lavado(TipoLavado _tipoLavado) //
	: tipoLavado(_tipoLavado), costo(0.0), cliente(NULL) {
	// empty
}

Lavado::Lavado(Cliente *_cliente) //
	: tipoLavado(Normal), costo(0.0), cliente(_cliente) {
	setCosto();
}

Lavado::Lavado(TipoLavado _tipoLavado, Cliente *_cliente) //
	: tipoLavado(_tipoLavado), costo(0.0), cliente(_cliente) {
	setCosto();
}

Lavado::Lavado(const Lavado &lavado) //
	: tipoLavado(lavado.tipoLavado), //
	  costo(lavado.costo), //
	  cliente(lavado.cliente) {
	setCosto();
}

Lavado::~Lavado() {
	// empty
}

TipoLavado Lavado::getTipoLavado() {
	return this->tipoLavado;
}

void Lavado::setTipoLavado(TipoLavado tipoLavado) {
	this->tipoLavado = tipoLavado;
}

double Lavado::getCosto() {
	return this->costo;
}

void Lavado::setCosto() {

	if ((cliente == NULL) || (cliente->getVehiculo() == NULL)) {
		return;
	}

	this->costo = (getCostoTipoLavado() * cliente->getVehiculo()->getPesoCosto()) //
			* (1 - cliente->getDescuento());

}

void Lavado::setCosto(const double &costo) {
	this->costo = costo;
}

Cliente *Lavado::getCliente() {
	return this->cliente;
}

void Lavado::setCliente(Cliente *_cliente) {
	this->cliente = _cliente;
}

void Lavado::mostrarLavado() {

	cout << endl << "Información del lavado:"
		 << endl << "Cliente: "
		 << cliente->getNombre()
		 << endl << "Cédula: " << cliente->getCedula()
		 << endl << "Vehículo: " << cliente->getVehiculo()->getMarca()
		 << " " << cliente->getVehiculo()->getModelo()
		 << " Año " << cliente->getVehiculo()->getAnyo()
		 << endl << "Tipo de lavado: " << tipoLavadoToString()
		 << endl << endl << "Costo del lavado: " << costo << "Bs.";

}

double Lavado::getCostoTipoLavado() {

	switch (tipoLavado) {
	case Normal:
		return 200.0;
		break;
	case Gamuzado:
		return 150.0;
		break;
	case Motor:
		return 300.0;
		break;
	case NormalGamuzado:
		return 320.0;
		break;
	case NormalMotor:
		return 450.0;
		break;
	case Full:
		return 600.0;
		break;
	default:
		return 200.0;
		break;
	}

}

string Lavado::tipoLavadoToString() {

	switch (tipoLavado) {
	case Normal:
		return string("Normal");
	case Gamuzado:
		return string("Gamuzado");
	case Motor:
		return string("Motor");
	case NormalGamuzado:
		return string("Normal + Gamuzado");
	case NormalMotor:
		return string("Normal + Motor");
	case Full:
		return string("Full");
	default:
		return string("Normal");
	}

}
