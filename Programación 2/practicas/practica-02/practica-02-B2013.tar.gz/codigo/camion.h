#ifndef CAMION_H
#define CAMION_H

#include "vehiculo.h"

#define PESO_COSTO_CAMION 1.2

class Camion : public Vehiculo {

public:
	Camion();

	Camion(const int &_id, const string &_marca, //
		   const string &_modelo, const int &_anyo);

	Camion(Camion *camion);

	~Camion();

};

#endif // CAMION_H
