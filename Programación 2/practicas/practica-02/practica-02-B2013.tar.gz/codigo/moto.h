#ifndef MOTO_H
#define MOTO_H

#include "vehiculo.h"

#define PESO_COSTO_MOTO 0.8

class Moto : public Vehiculo {

public:
	Moto();

	Moto(const int &_id, const string &_marca, //
		 const string &_modelo, const int &_anyo);

	Moto(Moto *moto);

	~Moto();

};

#endif // MOTO_H
