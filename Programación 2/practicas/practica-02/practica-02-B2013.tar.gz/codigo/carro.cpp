#include "carro.h"

Carro::Carro() : Vehiculo() {
	setPesoCosto(PESO_COSTO_CARRO);
}

Carro::Carro(const int &_id, const string &_marca, //
			 const string &_modelo, const int &_anyo) //
	: Vehiculo(_id, _marca, _modelo, _anyo) {
	setPesoCosto(PESO_COSTO_CARRO);
}

Carro::Carro(Carro *carro) //
	: Vehiculo(carro->Vehiculo::getId(), carro->Vehiculo::getMarca(), //
			   carro->Vehiculo::getModelo(), carro->Vehiculo::getAnyo()) {
	setPesoCosto(PESO_COSTO_CARRO);
}

Carro::~Carro() {
	// empty
}
