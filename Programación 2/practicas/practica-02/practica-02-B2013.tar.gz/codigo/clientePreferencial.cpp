#include "clientePreferencial.h"

ClientePreferencial::ClientePreferencial() : Persona(), Empleado(), Cliente() {
	setDescuentoPreferencial();
}

ClientePreferencial::ClientePreferencial(const int &ced, const string &nom, //
										 const string &dir, TipoEmpleado tipo) //
	: Persona(ced, nom, dir), Empleado(ced, nom, dir, tipo), Cliente(ced, nom, dir) {
	setDescuentoPreferencial();
}

ClientePreferencial::ClientePreferencial(const int &ced, const string &nom, //
										 const string &dir, TipoEmpleado tipo, //
										 Vehiculo *_vehiculo) //
	: Persona(ced, nom, dir), Empleado(ced, nom, dir, tipo), //
	  Cliente(ced, nom, dir, _vehiculo) {
	setDescuentoPreferencial();
}

ClientePreferencial::ClientePreferencial(ClientePreferencial *clientePreferencial) //
	: Persona(clientePreferencial->Empleado::getCedula(), //
			  clientePreferencial->Empleado::getNombre(), //
			  clientePreferencial->Empleado::getDireccion()), //
	  Empleado(clientePreferencial->Empleado::getCedula(), //
			   clientePreferencial->Empleado::getNombre(), //
			   clientePreferencial->Empleado::getDireccion(), //
			   clientePreferencial->Empleado::getTipoEmpleado()), //
	  Cliente(clientePreferencial->Empleado::getCedula(), //
			  clientePreferencial->Empleado::getNombre(), //
			  clientePreferencial->Empleado::getDireccion(), //
			  clientePreferencial->Cliente::getVehiculo()) {
	setDescuentoPreferencial();
}

ClientePreferencial::~ClientePreferencial() {
	// empty
}

void ClientePreferencial::setDescuentoPreferencial() {

	switch (getTipoEmpleado()) {
	case Contratado:
		setDescuento(0.25);
		break;
	case Fijo:
		setDescuento(0.3);
		break;
	case Administrativo:
		setDescuento(0.35);
		break;
	case ManoDeObra:
		setDescuento(0.4);
		break;
	case Antiguo:
		setDescuento(0.5);
		break;
	default:
		setDescuento(0.0);
		break;
	}
}

void ClientePreferencial::mostrarClientePreferencial() {

	cout << endl << "Datos del cliente preferencial: "
		 << endl << "Cédula: " << getCedula()
		 << endl << "Nombre: " << getNombre()
		 << endl << "Dirección: " << getDireccion()
		 << endl << "Tipo de empleado: " << tipoEmpleadoToString()
		 << endl << "Descuento: " << (getDescuento() * 100) << " %";

}
