#include "empleado.h"

Empleado::Empleado() : Persona() {
	leerDatos();
}

Empleado::Empleado(const int &ced, const string &nom, //
				   const string &dir, TipoEmpleado tipo) //
	: Persona(ced, nom, dir), tipoEmpleado(tipo) {
	// empty
}

Empleado::Empleado(Empleado *empleado) //
	: Persona(empleado->Persona::getCedula(), //
			  empleado->Persona::getNombre(), //
			  empleado->Persona::getDireccion()), //
	  tipoEmpleado(empleado->tipoEmpleado) {
	// empty
}

Empleado::~Empleado() {
	// empty
}

TipoEmpleado Empleado::getTipoEmpleado() {
	return this->tipoEmpleado;
}

void Empleado::setTipoEmpleado(TipoEmpleado tipoEmpleado) {
	this->tipoEmpleado = tipoEmpleado;
}

void Empleado::mostrarEmpleado() {

	cout << endl << "Datos del empleado: "
		 << endl << "Cédula: " << getCedula()
		 << endl << "Nombre: " << getNombre()
		 << endl << "Dirección: " << getDireccion()
		 << endl << "Tipo de empleado: " << tipoEmpleadoToString();

}

void Empleado::leerDatos() {

	int ced;
	string nom;
	string dir;

	cout << endl << "Ingrese los datos de la persona:" << endl
		 << endl << "Cédula: ";
	cin >> ced;

	setCedula(ced);

	cout << "Nombre: ";
	cin >> nom;

	setNombre(nom);

	cout << "Dirección: ";
	cin >> dir;

	setDireccion(dir);

	leerTipoEmpleado();

}

void Empleado::leerTipoEmpleado() {

	int t = -1;

	cout << "Tipo de empleado: "
		 << endl << "\t1) Contratado"
		 << endl << "\t2) Fijo"
		 << endl << "\t3) Administrativo"
		 << endl << "\t4) ManoDeObra"
		 << endl << "\t5) Antiguo"
		 << endl << "\tOpción: ";
	cin >> t;

	switch (t - 1) {
	case 0:
		tipoEmpleado = Contratado;
		break;
	case 1:
		tipoEmpleado = Fijo;
		break;
	case 2:
		tipoEmpleado = Administrativo;
		break;
	case 3:
		tipoEmpleado = ManoDeObra;
		break;
	case 4:
		tipoEmpleado = Antiguo;
		break;
	default:
		break;
	}

}

string Empleado::tipoEmpleadoToString() {

	string str = "";

	switch (tipoEmpleado) {
	case Contratado:
		str = "Contratado";
		break;
	case Fijo:
		str = "Fijo";
		break;
	case Administrativo:
		str = "Administrativo";
		break;
	case ManoDeObra:
		str = "Mano de obra";
		break;
	case Antiguo:
		str = "Antiguo";
		break;
	default:
		break;
	}

	return str;

}
