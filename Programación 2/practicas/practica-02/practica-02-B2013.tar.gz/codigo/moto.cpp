#include "moto.h"

Moto::Moto() : Vehiculo() {
	setPesoCosto(PESO_COSTO_MOTO);
}

Moto::Moto(const int &_id, const string &_marca, //
		   const string &_modelo, const int &_anyo) //
	: Vehiculo(_id, _marca, _modelo, _anyo) {
	setPesoCosto(PESO_COSTO_MOTO);
}

Moto::Moto(Moto *moto) //
	: Vehiculo(moto->Vehiculo::getId(), moto->Vehiculo::getMarca(), //
			   moto->Vehiculo::getModelo(), moto->Vehiculo::getAnyo()) {
	setPesoCosto(PESO_COSTO_MOTO);
}

Moto::~Moto() {
	// empty
}
