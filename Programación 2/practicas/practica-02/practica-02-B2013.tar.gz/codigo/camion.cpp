#include "camion.h"

Camion::Camion() : Vehiculo() {
	setPesoCosto(PESO_COSTO_CAMION);
}

Camion::Camion(const int &_id, const string &_marca, //
			   const string &_modelo, const int &_anyo) //
	: Vehiculo(_id, _marca, _modelo, _anyo) {
	setPesoCosto(PESO_COSTO_CAMION);
}

Camion::Camion(Camion *camion) //
	: Vehiculo(camion->Vehiculo::getId(), camion->Vehiculo::getMarca(), //
			   camion->Vehiculo::getModelo(), camion->Vehiculo::getAnyo()) {
	setPesoCosto(PESO_COSTO_CAMION);
}

Camion::~Camion() {
	// empty
}
