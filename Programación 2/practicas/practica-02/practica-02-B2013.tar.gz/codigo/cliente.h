#ifndef CLIENTE_H
#define CLIENTE_H

#include "persona.h"
#include "vehiculo.h"

class Cliente : virtual public Persona {

	double descuento;

	Vehiculo *vehiculo;

public:
	Cliente();

	Cliente(const int &ced, const string &nom, const string &dir);

	Cliente(const int &ced, const string &nom, const string &dir, Vehiculo *_vehiculo);

	Cliente(Cliente *cliente);

	~Cliente();

	double getDescuento();

	void setDescuento(const double &descuento);

	Vehiculo *getVehiculo();

	void setVehiculo(Vehiculo *_vehiculo);

	void mostrarCliente();

};

#endif // CLIENTE_H
