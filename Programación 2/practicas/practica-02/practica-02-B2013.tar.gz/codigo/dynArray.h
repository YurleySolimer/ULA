/**
 * @file dynArray.h
 * @brief Definición e implementación de la Clase DynArray para representar un arreglo dinámico.
 * Se usan plantillas para el tipo de dato que se almacena en el arreglo.
 *
 * @author Donato Galo
 *         dgalo88@hotmail.com
 *
 * @date 21-ene-2014
 */

#ifndef DYNARRAY_H
#define DYNARRAY_H

#include <iostream>

using namespace std;

/**
 * @brief Definicion de la clase DynArray.
 */
template <typename T>
class DynArray {

	/** @brief Puntero a los datos que almacena el arreglo. */
	T *data;

	/** @brief Tamaño del arreglo. */
	int size;

public:
	/**
	 * @brief Constructor de DynArray.
	 * Inicializa los datos de la estructura.
	 */
	DynArray() : data(NULL), size(0) {
		// empty
	}

	/**
	 * @brief Constructor por copia de DynArray.
	 * Inicializa los datos de la estructura a partir de otro DynArray.
	 * @param array Arreglo a partir del cual se realiza la copia.
	 */
	DynArray(const DynArray<T> &array) //
		: data(array.data), size(array.size) {
		// empty
	}

	/**
	 * @brief Destructor de DynArray.
	 * Elimina los datos de la estructura.
	 */
	~DynArray() {
		empty();
	}

	/**
	 * @brief Comprobar si el arreglo esta vacio.
	 * @return true si el arreglo esta vacio, false en caso contrario.
	 */
	bool isEmpty() {
		return size == 0;
	}

	/**
	 * @brief Muestra el tamaño y los elementos del arreglo.
	 */
	void print() {

		if (isEmpty()) {
			cout << endl << "El arreglo esta vacio." << endl;
			return;
		}

		cout << endl << "Tamaño del arreglo = " << size << endl;

		for (int i = 0; i < size; i++) {
			cout << data[i];
			if (i < size - 1) {
				cout << ", ";
			}
		}

		cout << endl;

	}

	/**
	 * @brief Buscar el subindice del elemento item en el arreglo.
	 * @param item Elemento que se desea buscar.
	 * @return Subindice del elemento item en el arreglo o -1 si el elemento no existe.
	 */
	int search(const T &item) {

		if (isEmpty()) {
			return -1;
		}

		int idx = -1;

		for (int i = 0; i < size; i++) {
			if (this->data[i] == item) {
				idx = i + 1;
				break;
			}
		}

		return idx;

	}

	/**
	 * @brief Contar el numero de ocurrencias del elemento item en el arreglo.
	 * @param item Elemento que se desea contar.
	 * @return Numero de ocurrencias del elemento item en el arreglo.
	 */
	int countOccurrences(const T &item) {

		if (isEmpty()) {
			return 0;
		}

		int occurrences = 0;

		for (int i = 0; i < size; i++) {
			if (this->data[i] == item) {
				occurrences++;
			}
		}

		return occurrences;

	}

	/**
	 * @brief Insertar el elemento item al final del arreglo.
	 * @param item Elemento que se desea insertar.
	 */
	void insert(const T &item) {

		T *aux = new T[size + 1];

		for (int i = 0; i < size; i++) {
			aux[i] = this->data[i];
		}

		aux[size] = item;
		size++;
		delete [] this->data;
		this->data = aux;
		aux = NULL;
		delete aux;

	}

	/**
	 * @brief Insertar el elemento item al inicio del arreglo.
	 * @param item Elemento que se desea insertar.
	 */
	void append(const T &item) {

		T *aux = new T[size + 1];

		aux[0] = item;

		for (int i = 0; i < size; i++) {
			aux[i + 1] = this->data[i];
		}

		size++;
		delete [] this->data;
		this->data = aux;
		aux = NULL;
		delete aux;

	}

	/**
	 * @brief Eliminar el elemento item del arreglo.
	 * @param item Elemento que se desea eliminar.
	 */
	void remove(const T &item) {

		if (isEmpty()) {
			cout << endl << "El arreglo esta vacio." << endl;
			return;
		}

		int reps = countOccurrences(item);

		if (reps == 0) {
			cout << endl << "El elemento no existe." << endl;
			return;
		}

		T *aux = new T[size - reps];

		for (int i = 0, j = 0; i < size; i++) {
			if (this->data[i] == item) {
				continue;
			}
			aux[j++] = this->data[i];
		}

		size -= reps;
		delete [] this->data;
		this->data = aux;
		aux = NULL;
		delete aux;

	}

	/**
	 * @brief Eliminar el elemento en la posicion i del arreglo.
	 * @param i Subindice del elemento que se desea eliminar.
	 */
	void removeAt(const int &i) {

		if (isEmpty()) {
			cout << endl << "El arreglo esta vacio." << endl;
			return;
		}

		remove(this->data[i - 1]);

	}

	/**
	 * @brief Eliminar todos los elementos del arreglo.
	 */
	void empty() {

		if (isEmpty()) {
			return;
		}

		delete [] data;
		size = 0;

	}

};

#endif // DYNARRAY

