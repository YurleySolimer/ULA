#include "cliente.h"

Cliente::Cliente() : Persona(), descuento(0.0), vehiculo(NULL) {
	// empty
}

Cliente::Cliente(const int &ced, const string &nom, const string &dir) //
	: Persona(ced, nom, dir), descuento(0.0), vehiculo(NULL) {
	// empty
}

Cliente::Cliente(const int &ced, const string &nom, //
				 const string &dir, Vehiculo *_vehiculo) //
	: Persona(ced, nom, dir), descuento(0.0), vehiculo(_vehiculo) {
	// empty
}

Cliente::Cliente(Cliente *cliente) //
	: Persona(cliente->Persona::getCedula(), //
			  cliente->Persona::getNombre(), //
			  cliente->Persona::getDireccion()), //
	  descuento(0.0), vehiculo(cliente->vehiculo) {
	// empty
}

Cliente::~Cliente() {
	// empty
}

double Cliente::getDescuento() {
	return this->descuento;
}

void Cliente::setDescuento(const double &descuento) {
	this->descuento = descuento;
}

Vehiculo *Cliente::getVehiculo() {
	return this->vehiculo;
}

void Cliente::setVehiculo(Vehiculo *_vehiculo) {
	this->vehiculo = _vehiculo;
}

void Cliente::mostrarCliente() {

	cout << endl << "Datos del cliente: "
		 << endl << "Cédula: " << getCedula()
		 << endl << "Nombre: " << getNombre()
		 << endl << "Dirección: " << getDireccion()
		 << endl << "Descuento: " << (descuento * 100) << " %";

}
