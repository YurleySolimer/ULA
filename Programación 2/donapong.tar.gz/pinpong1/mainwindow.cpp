#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPalette>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //para colocar fondo de pantalla

    QPixmap pix("FONDO.PNG");
    pix =pix.scaled(this->size(),Qt::IgnoreAspectRatio);
    QPalette pal;
    pal.setBrush(QPalette::Background,pix);
    this->setPalette(pal);
    connect(ui->_jugar,SIGNAL(clicked()),this,SLOT(jugar));

      dig.exec();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::jugar()
{




}
