#ifndef DIALOGO_H
#define DIALOGO_H

#include <QDialog>

namespace Ui {
class Dialogo;
}

class Dialogo : public QDialog
{
    Q_OBJECT
    
public:
    explicit Dialogo(QWidget *parent = 0);
    ~Dialogo();
    int x;
    int y;
    int vel_x;
    int vel_y;

    
private:
    Ui::Dialogo *ui;
public slots:
   void mover_dona();
  void mover_barra2();
  void mover_barra1();
};

#endif // DIALOGO_H
