/********************************************************************************
** Form generated from reading UI file 'dialogo.ui'
**
** Created: Sat Jun 7 22:06:44 2014
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGO_H
#define UI_DIALOGO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Dialogo
{
public:
    QLabel *barra_izquierda;
    QLabel *dona;
    QLabel *barra_derecha;

    void setupUi(QDialog *Dialogo)
    {
        if (Dialogo->objectName().isEmpty())
            Dialogo->setObjectName(QString::fromUtf8("Dialogo"));
        Dialogo->resize(714, 523);
        barra_izquierda = new QLabel(Dialogo);
        barra_izquierda->setObjectName(QString::fromUtf8("barra_izquierda"));
        barra_izquierda->setGeometry(QRect(40, 210, 19, 111));
        dona = new QLabel(Dialogo);
        dona->setObjectName(QString::fromUtf8("dona"));
        dona->setGeometry(QRect(290, 220, 71, 71));
        barra_derecha = new QLabel(Dialogo);
        barra_derecha->setObjectName(QString::fromUtf8("barra_derecha"));
        barra_derecha->setGeometry(QRect(600, 190, 19, 111));

        retranslateUi(Dialogo);

        QMetaObject::connectSlotsByName(Dialogo);
    } // setupUi

    void retranslateUi(QDialog *Dialogo)
    {
        Dialogo->setWindowTitle(QApplication::translate("Dialogo", "Dialog", 0, QApplication::UnicodeUTF8));
        barra_izquierda->setText(QApplication::translate("Dialogo", "TextLabel", 0, QApplication::UnicodeUTF8));
        dona->setText(QApplication::translate("Dialogo", "TextLabel", 0, QApplication::UnicodeUTF8));
        barra_derecha->setText(QApplication::translate("Dialogo", "TextLabel", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialogo: public Ui_Dialogo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGO_H
