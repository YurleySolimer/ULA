Este laboratorio contiene los siguientes archivos:

-. README.txt: esto que est�s leyendo

-. Makefile: modifica los caminos de aleph-w y clang a los de tu
   plataforma

-. lab-06.pdf: enunciado del laboratorio

-. common.H: definiciones comunes y funciones utilitarias. NO LO
   MODIFIQUES

-. test.C: "minicito" test. Parte desde aqu� para dise�ar casos de prueba
   rigurosos, sistem�ticos y completos. 

-. stats.H: tu entrega

NOTA SOBRE LA CORRUPCI�N Y EL PLAGIO
====================================

Mucho se habla de la corrupci�n en estos tiempos. As� que aprovechando
esta "moda", me permito observarte que el plagio, en cualquiera de sus
niveles, es un acto de corrupci�n de los m�s serios, pues est�s
adjudic�ndote m�rito por un trabajo que no has hecho; quiz� es tan o m�s
criminal que robar dinero o bienes, pues el plagio es el robo del
trabajo de otro; trabajo que t� no has hecho. �No lo hagas!, ni copiar
el trabajo del otro ni d�rselo a otros. Piensa que si lo haces, y no
exagero, est�s comenzando tu vida como corrupto (si es que ya no ha
comenzado).

El objetivo de un ejercicio es aprender y ganar conocimiento. La
realizaci�n de un ejercicio es una experiencia �nica e individual de
aprendizaje que nadie m�s puede hacer por ti. Si plagias, aparte de que
te incluyes en el conjunto de los corruptos y pierdes toda autoridad
moral para criticar la corrupci�n, tambi�n desperdicias completamente
una oportunidad de enriquecimiento que se te est� dando.

Por otra parte, si plagias creas un clima de desconfianza que atenta
contra el dise�o y realizaci�n de estos ejercicios, cuyo prop�sito es
ense�arte y corregirte m�s que evaluarte. Cuando plagias, no s�lo
cometes un crimen y entras al conjunto de los corruptos, sino que le
restringes severamente a los dem�s sus oportunidades de aprendizaje.
