
# include <istream>

# include <ahSort.H>
# include <tpl_dynMat.H>
# include <tpl_tree_node.H>
# include <generate_tree.H>

# include <dictnode.H>

# include <grid.H>
# include <word-find.H>

void usage()
{
  cout << "usage" << endl
       << "    word-find word-find-file" << endl;
  exit(0);
}

int main(int argc, char *argv[])
{
  if (argc != 2)
    usage();

  ifstream word_find(argv[1]);
  if (not word_find.is_open())
    {
      cout << "cannot open file " << argv[1] << endl;
      exit(0);
    }

  Grid grid = load_grid(word_find);
  cout << grid << endl;
  WordFind(grid).solve(cin).for_each([] (const WordMove & t)
    {
		  cout << get<0>(t) << " ";
      get<1>(t).for_each([] (const Cell & c)
			 {
			   cout << "(" << get<0>(c) << "," << get<1>(c) << ")";
			 });
      cout << endl;
    });

//*********pruebas**********//
/*	WordFind d(grid); 
	Cnode a='a';
	Cnode * r= &a;
  d.legal_moves(5,5).	for_each([] (Cell elem){
		 cout << get<0>(elem) ;
		 cout<<",";
		 cout << get<1>(elem) << "    ";                    
	}); 
  d.legal_moves(5,6).	for_each([] (Cell elem){
		 cout << get<0>(elem) ;
		 cout<<",";
		 cout << get<1>(elem) << "    ";                    
	}); 
	d.extract_word_from_stack();
 d.search(0,0, r);*/

  return 0;
}
