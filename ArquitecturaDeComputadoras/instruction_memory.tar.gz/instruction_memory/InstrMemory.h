#ifndef INSTRMEMORY_H
#define INSTRMEMORY_H
#include <systemc.h>
#include <fstream>

class InstrMemory: public sc_module{

	public:
		sc_in< sc_uint<4> > dir_in;
		sc_out< sc_uint<4> >instr_out;
		SC_CTOR(InstrMemory){

			SC_METHOD(search);
			sensitive<<dir_in;
		
			memoryFile.open("memoryFile.txt");
}
		~InstrMemory(){
			memoryFile.close();
		}

	private:
		ifstream memoryFile;
		void search();

};
#endif
