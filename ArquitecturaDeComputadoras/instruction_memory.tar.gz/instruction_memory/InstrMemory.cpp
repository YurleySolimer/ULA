#include "InstrMemory.h"

void InstrMemory::search(){

	unsigned int dir;	
	sc_uint<4> instr;
	char instrTmp[4];

	dir= dir_in.read();

	memoryFile.seekg(dir*5, ios::beg);

	memoryFile.getline(instrTmp,5);

	for(int i=0; i<4;i++)
		instr[3-i] = (instrTmp[i] == '1') ? 1 : 0;

	instr_out.write(instr);
}
