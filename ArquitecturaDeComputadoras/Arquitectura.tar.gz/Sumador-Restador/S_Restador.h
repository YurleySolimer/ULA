#ifndef S_RESTADOR
#define S_RESTADOR
#include "Complementador.h"
#include "Sumador.h"


