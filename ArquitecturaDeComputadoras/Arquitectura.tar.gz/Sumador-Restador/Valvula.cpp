#include"Valvula.h"	

Valvula::Valvula(sc_module_name nm):sc_module(nm){ 


}
