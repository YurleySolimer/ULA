#ifndef VALVULA_H
#define VALVULA_H

#include "Buffer.h"
#include "S_Restador.h"

class Valvula public sc_module {
 	

	SC_CTOR(Valvula);
	~Valvula();

};

#endif
